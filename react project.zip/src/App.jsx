import React from 'react'
import './App.css'

const App = () => {
  const yourName = "Uzma Nazmeen";
  const yourAim = "To become a Successful Developer";
  const funFact = "I can make anyone smile with my talks!";

  return (
    <div className="container">
      <h1>Hello, I am {yourName} 👋</h1>
      <h2>{yourAim}</h2>
      <p>I'm currently learning how to build awesome UIs with React!</p>
      <p><b>Fun Fact:</b> {funFact} 🧑‍💻</p>
    </div>
  )
}

export default App